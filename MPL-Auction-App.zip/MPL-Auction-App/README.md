# MPL - Minority Premium League (Auction Tracker)
Push this repo to GitHub -> Actions tab -> "Build APK" -> Artifacts -> MPL-Auction-APK.
